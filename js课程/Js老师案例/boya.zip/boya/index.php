<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>博雅互动</title>
	<link rel="stylesheet" type="text/css" href="css/reset.css" />
	<link rel="stylesheet" type="text/css" href="css/base.css" />
	<link rel="stylesheet" type="text/css" href="css/common.css" />
	<link rel="stylesheet" type="text/css" href="css/index.css" />
</head>
<body>
		<!-- 头部 -->
	<div class="header">
		<div class="inner_c">
			<div class="logo">
				<h1><a href="#">博雅互动-专业游戏网站</a></h1>
			</div>
			<div class="nav">
				<ul>
					<li class="first current"><a href="">首页</a></li>
					<li><a href="">博雅游戏</a></li>
					<li><a href="">博雅新闻</a></li>
					<li><a href="">关于我们</a></li>
					<li><a href="">客服中心</a></li>
					<li><a href="">投资者关系</a></li>
					<li><a href="">校园大使</a></li>
				</ul>
			</div>
			<div class="joinus">
				<a href="">加入我们</a>
			</div>
		</div>
	</div>

	<div class="cl"></div>
	
	<!-- banner -->
	<div class="banner">
		<img src="images/banner1.jpg" alt="" />
		<div class="circles">
			<ol>
				<li class="cur"></li>
				<li></li>
				<li></li>
				<li class="nomargin"></li>
			</ol>
		</div>
	</div>

	<div class="cl"></div>
	
	<!-- 产品 -->
	<div class="product inner_c">
		<ul>
			<li>
				<a href="">
					<img src="images/pro1.png" alt="" />
					<span class="c">四川麻将</span>
					<span class="e"><b>SICHUAN MAJIANG</b></span>
				</a>
			</li>
			<li>
				<a href="">
					<img src="images/pro1.png" alt="" />
					<span class="c">四川麻将</span>
					<span class="e"><b>SICHUAN MAJIANG</b></span>
				</a>
			</li>
			<li>
				<a href="">
					<img src="images/pro1.png" alt="" />
					<span class="c">四川麻将</span>
					<span class="e"><b>SICHUAN MAJIANG</b></span>
				</a>
			</li>
			<li class="nomargin last">
				<a href="">
					<img src="images/pro1.png" alt="" />
					<span class="c">四川麻将</span>
					<span class="e"><b>SICHUAN</b></span>
				</a>
			</li>
		</ul>
		<div class="circles">
			<ol>
				<li class="cur"></li>
				<li></li>
				<li></li>
				<li class="nomargin"></li>
			</ol>
		</div>	
	</div>

	<div class="cl"></div>

	<!-- 信息 -->
	<div class="information">
		<div class="inner_c">
			<div class="news">
				<div class="hd">
					<h3>博雅新闻</h3>
					<a href="" class="more">MORE <sup>+</sup></a>
				</div>
				<div class="bd">
					<ul>
					<?php
						//连接数据库，很高兴的告诉你PHP和MySQL是好兄弟，只需要一行命令，就能链接数据库！
						//phpnow选手的默认的用户名是root，密码是123456
						//$con就是一个变量，表示一次连接
						$con = mysql_connect("localhost","root","123456");
				 		
				 		//选择链接哪个库？
						mysql_select_db("mydb", $con);

						//更改数据操作字符集
						mysql_query("SET NAMES UTF8");

						//执行SQL语句，就把检索结果放到了$result变量中
						$result = mysql_query("SELECT * FROM xinwen");

						//循环读取
						while($row = mysql_fetch_array($result)){
					?>
						<li class="first">
							<span class="date"><?php echo $row["riqi"]; ?></span>
							<span class="title">
								<a target="_blank" href="game.php?id=<?php echo $row["id"]; ?>"><?php echo $row["biaoti"]; ?></a>
							</span>
						</li>
					<?php
						}

						//关闭数据库
						mysql_close($con);
					?>
					</ul>
				</div>
			</div>
			<div class="jobs">
				<div class="hd">
					<h3>
						<span class="c">专场招聘</span>
						<span class="e">BOYAA JOBS</span>
					</h3>
					<a href="" class="more">MORE <sup>+</sup></a>
				</div>
				<div class="bd">
					<h4>专场招聘岗位：</h4>
					<ul>
						<li><a href="">PHP开发工程师</a></li>
						<li><a href="">PHP开发工程师</a></li>
						<li><a href="">PHP开发工程师</a></li>
						<li><a href="">PHP开发工程师</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>

	<div class="cl"></div>
	<!-- 页脚 -->
	<div class="footer">
		<div class="inner_c">
			<div class="links">
				<a href="#">网站地图</a>
				<span>|</span>
				<a href="#">免责声明</a>
			</div>
			<div class="copyright">
				Copyright © 2004 - 2016 博雅互动(Boyaa Interactive) 
				<a href="">粤ICP备05062536号</a>
				增值电信业务经营许可证：粤B2-20110513
				<img src="images/govIcon.gif" alt="" class="govicon" />
			</div>
		</div>
	</div>
</body>
</html>